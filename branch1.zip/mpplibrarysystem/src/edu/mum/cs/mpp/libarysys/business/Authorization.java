package edu.mum.cs.mpp.libarysys.business;

public enum Authorization {
	LIBRARIAN,
	ADMIN,  
	BOTH;
}
